const $ = (id) => document.getElementById(id);
$('year').textContent = new Date().getFullYear();

const menuToggle = $('menuToggle');
const nav = $('nav');
menuToggle.addEventListener('click', () => nav.classList.toggle('open'));
nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => nav.classList.remove('open')));

$('themeToggle').addEventListener('click', () => {
  document.body.classList.toggle('light');
  localStorage.setItem('mech-ai-theme', document.body.classList.contains('light') ? 'light' : 'dark');
  if (window.mechCharts) window.mechCharts.forEach(chart => chart.update());
});
if (localStorage.getItem('mech-ai-theme') === 'light') document.body.classList.add('light');

const labels = ['10:00','10:05','10:10','10:15','10:20','10:25','10:30','10:35','10:40','10:45','10:50','10:55'];
const baseVibration = [0.31,0.35,0.33,0.38,0.36,0.42,0.40,0.39,0.44,0.41,0.43,0.42];
const baseTemp = [26.8,27.0,27.1,27.3,27.4,27.7,27.9,28.0,28.1,28.2,28.3,28.4];
const baseHumidity = [68,67,67,66,66,65,65,64,64,64,63,64];
const gridColor = () => getComputedStyle(document.body).getPropertyValue('--line').trim() || '#203247';
const tickColor = () => getComputedStyle(document.body).getPropertyValue('--muted').trim() || '#8da2bb';
const commonOptions = {responsive:true, maintainAspectRatio:false, interaction:{intersect:false,mode:'index'}, plugins:{legend:{display:false},tooltip:{backgroundColor:'#07111f',titleColor:'#eaf3ff',bodyColor:'#b9cbe0',borderColor:'#29445e',borderWidth:1}}, scales:{x:{grid:{display:false},ticks:{color:tickColor(),font:{size:9},maxRotation:0},border:{color:gridColor()}},y:{grid:{color:gridColor()},ticks:{color:tickColor(),font:{size:9}},border:{display:false}}}};
function lineDataset(label,data,color,extra={}) {return {label,data,borderColor:color,backgroundColor:color+'20',borderWidth:2,pointRadius:2,pointHoverRadius:4,tension:.35,fill:false,...extra};}
const vibrationChart = new Chart($('vibrationChart'), {type:'line',data:{labels,datasets:[lineDataset('Vibration (g)',baseVibration,'#50e5ef')]},options:structuredClone(commonOptions)});
const environmentChart = new Chart($('environmentChart'), {type:'line',data:{labels,datasets:[lineDataset('Temperature °C',baseTemp,'#648cff'),lineDataset('Humidity %',baseHumidity,'#50e5ef')]},options:structuredClone(commonOptions)});
const recoveryChart = new Chart($('recoveryChart'), {type:'line',data:{labels:['1','2','3','4','5','6','7','8','9','10','11','12'],datasets:[
  lineDataset('Observed', [0.31,0.35,0.34,0.38,null,null,0.43,0.41,0.44,0.42,0.43,0.42],'#50e5ef',{spanGaps:false}),
  lineDataset('Estimated', [null,null,null,0.38,0.395,0.415,0.43,null,null,null,null,null],'#f5bf5b',{borderDash:[5,5],pointStyle:'rectRot',pointRadius:4,spanGaps:false})
]},options:structuredClone(commonOptions)});
window.mechCharts = [vibrationChart,environmentChart,recoveryChart];

function randomizeDemo() {
  const vib = +(0.34 + Math.random()*0.18).toFixed(2);
  const temp = +(26 + Math.random()*5).toFixed(1);
  const hum = Math.round(55 + Math.random()*22);
  const rain = Math.round(Math.random()*45);
  const light = Math.round(40 + Math.random()*55);
  $('vibrationValue').textContent = vib.toFixed(2);
  $('temperatureValue').textContent = temp.toFixed(1);
  $('humidityValue').textContent = hum;
  $('rainValue').textContent = rain;
  $('lightValue').textContent = light;
  const status = $('vibrationStatus');
  if (vib > 0.48) {status.textContent = '● Review';status.className='status status-warn';}
  else {status.textContent='● Stable';status.className='status status-ok';}
  const shift = Math.random()*0.08-0.04;
  vibrationChart.data.datasets[0].data = baseVibration.map(v => +(v+shift+(Math.random()*.035-.017)).toFixed(2));
  environmentChart.data.datasets[0].data = baseTemp.map(v => +(v+(Math.random()*.7-.35)).toFixed(1));
  environmentChart.data.datasets[1].data = baseHumidity.map(v => Math.max(40,Math.min(90,Math.round(v+(Math.random()*4-2)))));
  vibrationChart.update(); environmentChart.update();
}
$('refreshBtn').addEventListener('click', randomizeDemo);
$('rangeSelect').addEventListener('change', (e) => {
  const isDay = e.target.value === 'day';
  const dayLabels = isDay ? ['00:00','02:00','04:00','06:00','08:00','10:00','12:00','14:00','16:00','18:00','20:00','22:00'] : labels;
  vibrationChart.data.labels = dayLabels;
  environmentChart.data.labels = dayLabels;
  vibrationChart.update(); environmentChart.update();
});
setInterval(randomizeDemo, 12000);

// Highlight the current section in the navigation.
const sections = [...document.querySelectorAll('main section[id]')];
if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver(entries => entries.forEach(entry => {
    if (entry.isIntersecting) {
      nav.querySelectorAll('a').forEach(a => a.classList.toggle('active', a.getAttribute('href') === '#'+entry.target.id));
    }
  }), {rootMargin:'-35% 0px -55% 0px'});
  sections.forEach(section => observer.observe(section));
}
